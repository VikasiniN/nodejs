module.exports = {
    url: 'mongodb+srv://ucchalmongodb:admin@cluster0-i4x9i.mongodb.net/test?retryWrites=true&w=majority'

    /* url: 'mongodb://localhost:27017/customer-service' */ 
}
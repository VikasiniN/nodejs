const env = {
	AWS_ACCESS_KEY: 'AKIAZVW7PCSB7WSN4Z7L', // change to yours
	AWS_SECRET_ACCESS_KEY: 'sCUrj6l9bMpi2hAMQegPWDOE/hXT/y5tcZujpZxd', // change to yours
	REGION : 'ap-south-1', // change to yours
    Bucket: 'ucchalfashion-images', // change to yours
    ImageServerPath: 'https://ucchalfashion-images.s3.ap-south-1.amazonaws.com/images/'
};
 
module.exports = env;
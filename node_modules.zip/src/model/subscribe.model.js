var mongoose = require('mongoose');
const subscribeSchema = new mongoose.Schema({

   emailId: String

});
var subscribe = mongoose.model('subscribe', subscribeSchema);
module.exports = subscribe;
var measurementMgr = require('./measurementMgr');

module.exports = function(app) {
    app.route('/addmeasurementbycustomer')
        .post(measurementMgr.addMeasurement);
        app.route('/getselectedmeasurement/:id')
        .get(measurementMgr.getSelectedMeasurement);
        app.route('/getallmeasurementbyuser')
        .get(measurementMgr.getAllMeasurement);
        app.route('/getmeasurementforuser/:id/:mesId')
        .get(measurementMgr.getMeasurementUser);
        app.route('/deletemeasurement/:id')
        .delete(measurementMgr.deleteMeasurement);
        app.route('/checkfrontneckstyle')
        .post(measurementMgr.checkFrontNeckStyle);
        app.route('/checkbackneckstyle')
        .post(measurementMgr.checkBackNeckStyle);
        app.route('/checksleevestyle')
        .post(measurementMgr.checkSleeveStyle);
        app.route('/checkbottomstyle')
        .post(measurementMgr.checkBottomStyle);
}
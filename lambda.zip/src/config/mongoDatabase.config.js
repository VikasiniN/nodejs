module.exports = {
  url:
    "mongodb+srv://admin:admin@cluster0-rkwbl.mongodb.net/test?retryWrites=true&w=majority"
};
